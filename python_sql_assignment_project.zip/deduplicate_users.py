import pandas as pd

def deduplicate_users(file_path: str, output_path: str) -> None:
    df = pd.read_csv(file_path)
    df['last_updated'] = pd.to_datetime(df['last_updated'])
    deduped_df = df.sort_values('last_updated', ascending=False).drop_duplicates(subset='email', keep='first')
    deduped_df.to_csv(output_path, index=False)

if __name__ == "__main__":
    deduplicate_users('users.csv', 'deduplicated_users.csv')