import pandas as pd

def extract_reviews(file_path: str) -> pd.DataFrame:
    return pd.read_csv(file_path)

def transform_reviews(df: pd.DataFrame) -> pd.DataFrame:
    df = df.dropna(subset=['rating', 'review_text'])
    df['rating'] = df['rating'].astype(int)
    df = df[df['rating'].between(1, 5)]
    df['sentiment'] = df['review_text'].apply(lambda text: 'Negative' if 'bad' in text.lower() else 'Positive')
    return df

def load_reviews(df: pd.DataFrame, output_path: str) -> None:
    df.to_csv(output_path, index=False)

if __name__ == "__main__":
    raw_df = extract_reviews('product_reviews.csv')
    clean_df = transform_reviews(raw_df)
    load_reviews(clean_df, 'cleaned_reviews.csv')