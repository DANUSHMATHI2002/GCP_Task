import pandas as pd

def identify_vip_customers(purchase_path: str, member_path: str) -> pd.DataFrame:
    purchases = pd.read_csv(purchase_path)
    members = pd.read_csv(member_path)
    df = pd.merge(purchases, members, on='customer_id')
    grouped = df.groupby(['customer_id', 'membership_level'], as_index=False)['amount'].sum()
    vip_df = grouped[(grouped['amount'] > 250) & (grouped['membership_level'] == 'Gold')].rename(columns={'amount': 'total_spent'})
    return vip_df

if __name__ == "__main__":
    vip_customers = identify_vip_customers('purchases.csv', 'members.csv')
    vip_customers.to_csv('vip_customers.csv', index=False)